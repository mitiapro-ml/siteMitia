import profile from "./data/profile.js";
import Hero from "./components/Hero.jsx";
import Skills from "./components/Skills.jsx";
import Projects from "./components/Projects.jsx";
import Timeline from "./components/Timeline.jsx";
import Contact from "./components/Contact.jsx";

export default function App() {
  return (
    <>
      <div className="wrap">
        <nav aria-label="Navigation principale">
          <b>{profile.name}</b>
          <div>
            <a href="#competences">Compétences</a>
            <a href="#projets">Projets</a>
            <a href="#parcours">Parcours</a>
            <a href="#contact">Contact</a>
          </div>
        </nav>
        <Hero profile={profile} />
      </div>
      <Skills skills={profile.skills} languages={profile.languages} />
      <Projects projects={profile.projects} />
      <Timeline id="parcours" title="Expérience" items={profile.experience} />
      <Timeline title="Formation" items={profile.education} />
      <Contact contact={profile.contact} />
      <footer>
        <div className="wrap">© {new Date().getFullYear()} {profile.name}</div>
      </footer>
    </>
  );
}
