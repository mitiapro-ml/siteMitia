export default function Skills({ skills, languages }) {
  return (
    <section id="competences">
      <div className="wrap">
        <h2>Compétences</h2>
        <div className="skills">
          {skills.map((g) => (
            <div key={g.title}>
              <h3>{g.title}</h3>
              <ul>{g.items.map((i) => <li key={i}>{i}</li>)}</ul>
            </div>
          ))}
        </div>
        <p className="langs">Langues : {languages}</p>
      </div>
    </section>
  );
}
