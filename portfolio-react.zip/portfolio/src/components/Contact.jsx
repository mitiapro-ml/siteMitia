export default function Contact({ contact }) {
  return (
    <section id="contact" className="contact">
      <div className="wrap">
        <h2>Travaillons ensemble</h2>
        <p>{contact.text}</p>
        <div className="btns">
          {contact.email && <a className="btn main" href={`mailto:${contact.email}`}>{contact.email}</a>}
          {contact.linkedin && <a className="btn" href={contact.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>}
          {contact.github && <a className="btn" href={contact.github} target="_blank" rel="noreferrer">GitHub</a>}
        </div>
      </div>
    </section>
  );
}
