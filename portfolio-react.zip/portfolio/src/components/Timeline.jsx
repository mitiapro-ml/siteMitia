export default function Timeline({ id, title, items }) {
  return (
    <section id={id}>
      <div className="wrap">
        <h2>{title}</h2>
        <ol className="tl">
          {items.map((it) => (
            <li key={it.title + it.period}>
              <h3>{it.title}</h3>
              <small>{it.org} · {it.period}</small>
              {it.points.length > 0 && <ul>{it.points.map((pt) => <li key={pt}>{pt}</li>)}</ul>}
              {it.stack && <p className="stack">Stack : {it.stack}</p>}
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
