export default function Projects({ projects }) {
  return (
    <section id="projets">
      <div className="wrap">
        <h2>Projets</h2>
        <div className="projects">
          {projects.map((p) => (
            <article className="proj" key={p.title}>
              <div>
                <h3>{p.title}</h3>
                <small>{p.type}</small>
                <p>{p.description}</p>
                <div className="tags">{p.stack.map((s) => <span key={s}>{s}</span>)}</div>
                {p.link && <p><a href={p.link} target="_blank" rel="noreferrer">Voir le code</a></p>}
              </div>
              {p.result && (
                <div className="res">
                  <strong>{p.result.value}</strong>
                  <span>{p.result.label}</span>
                </div>
              )}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
